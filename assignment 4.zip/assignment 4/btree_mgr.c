#include "dberror.h"
#include "tables.h"
#include "btree_mgr.h"
#include "buffer_mgr.h"
#include "record_mgr.h"
#include "storage_mgr.h"

#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int totalKeys;
    Value **key;
    RID rid;
    bool leaf;              
    struct Node *parent;    
    struct Node **next;     
    void **p;               
} Node;


Node* getLeafNode(Node *start, Value *key);
bool compareKeys(Value *key1, Value *key2);

typedef struct IndexMgr{
    int order;
    Node *root;
    Node *queue;
    int totalNodes;
    int totalEntries;
    BM_PageHandle bph;
    BM_BufferPool pool;
    DataType keyType;       
} IndexMgr;

IndexMgr *iManager = NULL;
int max;
int idx = 0;  


Node* makeNewNode(BTreeHandle *tree) {
    IndexMgr *iMgr = (IndexMgr*)tree->mgmtData;
    Node *node = malloc(sizeof(Node));
    node->key = malloc((iMgr->order - 1) * sizeof(Value *));
    node->p = malloc(iMgr->order * sizeof(void *));
    node->totalKeys = 0;
    node->leaf = false;
    node->parent = NULL;
    node->next = NULL;

    iMgr->totalNodes++; 
    return node;
}


Node* getLeafNode(Node *start, Value *key) {
    int i = 0;
    Node *node = start;
    if (node == NULL) return NULL;
    while (!node->leaf) {
        i = 0;
        while(i < node->totalKeys && key->v.intV >= node->key[i]->v.intV) {
            i++;
        }
        node = (Node *) node->p[i];
    }
    return node;
}

bool compareKeys(Value *key1, Value *key2) {
    return key1->v.intV == key2->v.intV;
}


extern RC initIndexManager (void *mgmtData){
    printf("Initializing Index Manager\n");
    return RC_OK;
}

extern RC shutdownIndexManager (){
    printf("Shutting Down Index Manager\n");
    iManager = NULL;
    return RC_OK;
}


extern RC createBtree (char *idxId, DataType keyType, int n){
    max = PAGE_SIZE/sizeof(Node);
    if (n > max) {
		return RC_IM_N_TO_LAGE;
	}
    
    iManager = (IndexMgr*)malloc(sizeof(IndexMgr));
    
    
    iManager->order = n+2;
    iManager->root = NULL;
    iManager->queue = NULL;
    iManager->totalNodes = 0;
    iManager->totalEntries = 0;
    iManager->keyType = keyType;

    BM_BufferPool * bm = (BM_BufferPool *) malloc(sizeof(BM_BufferPool));
	iManager->pool = *bm;
    
    // set the tree order
    max = PAGE_SIZE/sizeof(Node);

    SM_FileHandle fh;
    

    createPageFile (idxId);
    openPageFile(idxId, &fh);
    char data[PAGE_SIZE];
    writeBlock(0, &fh, data);
    closePageFile(&fh);

    printf("B+ tree created\n");
    return RC_OK;
}

extern RC openBtree (BTreeHandle **tree, char *idxId){
    // malloc and store our metadata
    *tree = (BTreeHandle *)malloc(sizeof(BTreeHandle));
    (*tree)->mgmtData = iManager;

    
	initBufferPool(&iManager->pool, idxId, 2000, RS_FIFO, NULL);

    return RC_OK;
}

extern RC closeBtree (BTreeHandle *tree){
    // retrieve the metadata in mgmtData
    IndexMgr *newMgr = (IndexMgr*)tree->mgmtData;
    // write data back to disk and shut down buffer pool
    markDirty(&newMgr->pool, &newMgr->bph);
    shutdownBufferPool(&newMgr->pool);

    // free memory
    free(newMgr);
    free(tree);

    printf("Closed B+ tree\n");
    return RC_OK;
}

extern RC deleteBtree (char *idxId){
    destroyPageFile(idxId);
    free(iManager->root);
    printf("Deleted B+ tree\n");
    return RC_OK;
}

// access information about a b-tree
extern RC getNumNodes (BTreeHandle *tree, int *result){
    // retrieve the metadata using a new IndexMgr
    IndexMgr *newMgr = (IndexMgr*)tree->mgmtData;
    *result = newMgr->totalNodes;
    return RC_OK;
}

extern RC getNumEntries (BTreeHandle *tree, int *result){
    // retrieve the metadata using a new IndexMgr
    IndexMgr *newMgr = (IndexMgr*)tree->mgmtData;
    *result = newMgr->totalEntries;
    return RC_OK;
}

extern RC getKeyType (BTreeHandle *tree, DataType *result){
    // retrieve the metadata using a new IndexMgr
    IndexMgr *newMgr = (IndexMgr*)tree->mgmtData;
    *result = newMgr->keyType;
    return RC_OK;
}

// index access
extern RC findKey (BTreeHandle *tree, Value *key, RID *result){
    // retrieve the metadata using a new IndexMgr
    IndexMgr *newMgr = (IndexMgr*)tree->mgmtData;
    // new Node to search for the passed RID
    Node *node;

   
    node = getLeafNode(newMgr->root, key);
    if (node == NULL) {
        return RC_IM_KEY_NOT_FOUND;
    }
    int i = 0;
    
    
    for (i = 0; i < node->totalKeys; i++){
        if (key->v.intV == node->key[i]->v.intV) {
            break;
        }
    } 
    if (i == node->totalKeys){
        node = NULL;
        return RC_IM_KEY_NOT_FOUND;
    }
    RID r = *(RID *) node->p[i];
    *result = r;
    return RC_OK;
}


Node* insertKeyIntoParentNode(BTreeHandle *tree, Node *leftNode, Value *key, Node *rightNode) {
    
    IndexMgr *newMgr = iManager;
    int order = iManager->order;
    Node * parent = leftNode->parent;

    
    if (parent == NULL) {
        Node * newRoot = makeNewNode(tree);
        newRoot->key[0] = key;
        newRoot->p[0] = leftNode;
        newRoot->p[1] = rightNode;
        newRoot->totalKeys++;
        newRoot->parent = NULL;
        leftNode->parent = newRoot;
        rightNode->parent = newRoot;

        newMgr->root = newRoot;
        return newRoot;
    }

    int leftNodeLocation = 0;
    while (leftNodeLocation <= parent->totalKeys && parent->p[leftNodeLocation] != leftNode) {
        leftNodeLocation += 1;
    }
    // insert the new key into a node that can fit it
    if (parent->totalKeys < order - 1) {
        for (int i = parent->totalKeys; i > leftNodeLocation; i--) {
            parent->p[i + 1] = parent->p[i];
            parent->key[i] = parent->key[i - 1];
        }
        parent->p[leftNodeLocation + 1] = rightNode;
	    parent->key[leftNodeLocation] = key;
	    parent->totalKeys++;
        return newMgr->root;
    }

    Value **keys = malloc(order * sizeof(Value));
    Node **pointers = malloc((order + 1) * sizeof(Node *));
    int j=0;
    for (int i = 0; i < parent->totalKeys + 1; i++) {
        if (j == leftNodeLocation + 1) {
            j++;
        }
        pointers[j] = parent->p[i];
        j++;
    }
    j=0;
    for (int i = 0; i < parent->totalKeys; i++) {
        if (j == leftNodeLocation) {
            j++;
        }
        pointers[j] = parent->p[i];
        j++;
    }
    pointers[leftNodeLocation + 1] = rightNode;
    keys[leftNodeLocation] = key;
    
    int split = 0;
    int i=0;
    if ((order - 1) % 2 == 0)
		split = (order - 1) / 2;
	else
		split = (order - 1) / 2 + 1;

	Node *new_node = makeNewNode(tree);
    new_node->leaf = TRUE;
	parent->totalKeys = 0;
	for (i = 0; i < split - 1; i++) {
		parent->p[i] = pointers[i];
		parent->key[i] = keys[i];
		parent->totalKeys++;
	}
	parent->p[i] = pointers[i];
	Value *kNew = keys[split - 1];
	for (++i, j = 0; i < order; i++, j++) {
		new_node->p[j] = pointers[i];
		new_node->key[j] = keys[i];
		new_node->totalKeys++;
	}
	new_node->p[j] = pointers[i];
	free(pointers);
	free(keys);
	new_node->parent = parent->parent;
    Node *child;
	for (i = 0; i <= new_node->totalKeys; i++) {
		child = new_node->p[i];
		child->parent = new_node;
	}
    newMgr->totalEntries++;
    return insertKeyIntoParentNode(tree, parent, kNew, new_node);
}

extern RC insertKey (BTreeHandle *tree, Value *key, RID rid){
    // retrieve the metadata using a new IndexMgr
    IndexMgr *newMgr = (IndexMgr*)tree->mgmtData;
    int order = iManager->order;        // store the order
    printf("   -> insertKey() function STARTED\n");

    // check if record with key is already in the tree
    RID *r = NULL;
    if (findKey(tree, key, r) == RC_OK) {
        printf("\nKey is already inserted in tree\n");
        return RC_WRITE_FAILED;
    }

    // initialize a record id to store the new key 
    RID *newRecord = malloc(sizeof(RID));
    newRecord->page = rid.page;
    newRecord->slot = rid.slot;

    // Create a new b tree if one does not already exist
    if(newMgr->root == NULL) {
        Node *root = makeNewNode(tree);
        root->key[0] = key; 
        root->p[0] = newRecord;
        root->p[order - 1] = NULL;
        root->parent = NULL;
        root->totalKeys++;
        root->leaf = TRUE;

        newMgr->root = root;
        newMgr->totalEntries++;
        printf("\t>>>>>>>>>>>>>>>>>Inserted key into new tree\n");
        return RC_OK;
    }

    Node *leafNode;
    leafNode = getLeafNode(newMgr->root, key);

    // Check if node has space to insert a new key
    if (leafNode->totalKeys < order - 1) {
        newMgr->totalEntries++;
        
        // find where to insert the key
        int key_index = 0;
        while (key_index < leafNode->totalKeys && (key->v.intV > leafNode->key[key_index]->v.intV)) {
            // check that the current node is less than the key we want to insert
            key_index++;
        }
        // adjust the tree
        for (int i = leafNode->totalKeys; i > key_index; i--) {
            leafNode->key[i] = leafNode->key[i - 1];
            leafNode->p[i] = leafNode->p[i - 1];
        }
        leafNode->key[key_index] = key;
        leafNode->p[key_index] = newRecord;
        leafNode->totalKeys++;

        printf("\t>>>>>>>>>>>>>>>>>Inserted key into existing leaf\n");
        return RC_OK;
    }


    
    Node *newLeafNode = makeNewNode(tree);
    newLeafNode->leaf = TRUE;
    
    Value **keys = malloc(order * sizeof(Value));
    void ** p = malloc(order * sizeof(void *));

    
    int key_index = 0;
    while (key_index < leafNode->totalKeys) {
        
        if (key->v.intV > leafNode->key[key_index]->v.intV) {
            key_index++;
        }
        else {
            break;
        }
    }
    
    
    int j = 0;
    for (int i = 0; i < leafNode->totalKeys; i++) {
        if (j == key_index) {
            j++;
        }
        keys[j] = leafNode->key[i];
        p[j] = leafNode->p[i];
        j++;
    }
    keys[key_index] = key;
	p[key_index] = newRecord;
    leafNode->totalKeys = 0;
    
    // Split the leaf node
    int split = 0;
    int i = 0;
    if ((order - 1) % 2 == 0) {
		split = (order - 1) / 2;
    }
	else {
		split = (order - 1) / 2 + 1;
    }
	for (i = 0; i < split; i++) {
		leafNode->p[i] = p[i];
		leafNode->key[i] = keys[i];
		leafNode->totalKeys++;
	}
	for (i = split, j = 0; i < order; i++, j++) {
		newLeafNode->p[j] = p[i];
		newLeafNode->key[j] = keys[i];
		newLeafNode->totalKeys++;
	}
    
    // adjust parents
    newLeafNode->p[order - 1] = leafNode->p[order - 1];
	leafNode->p[order - 1] = newLeafNode;

	for (int i = leafNode->totalKeys; i < order - 1; i++)
		leafNode->p[i] = NULL;
	for (int i = newLeafNode->totalKeys; i < order - 1; i++)
		newLeafNode->p[i] = NULL;

	newLeafNode->parent = leafNode->parent;
	Value *newLeafKey = newLeafNode->key[0];


    free(keys);
	free(p);
    newMgr->totalEntries++;

    
    newMgr->root = insertKeyIntoParentNode(tree, leafNode, newLeafKey, newLeafNode);

    printf("\t>>>>>>>>>>>>>>>>>Inserted key after Splitting leaf\n");
    return RC_OK;
}
// Helper function to perform the deletion
Node *delRecord(BTreeHandle *tree, Node *newNode, Value *key, void *p){
    IndexMgr *newMgr = (IndexMgr*) tree->mgmtData;
    // local variables needed to delete
    Node *neighborNode;
    int neighborIndex, minKeys, kIndex, capacity;
    Value *k;

    int i = 0;
    int order;
    order = newMgr->order;

    
    
    while (!compareKeys(key, newNode->key[i])){
        i++;
    }
    
    for (++i; i < newNode->totalKeys; i++){
        newNode->key[i-1] = newNode->key[i];
    }
    
    int totalPointers;
    if (newNode->leaf){
        totalPointers = newNode->totalKeys;        }
    else{
        totalPointers = newNode->totalKeys+1;
    }

    
    i = 0;
    
    while(p != newNode->p[i]){
        i++;
    }
    for (++i; i < totalPointers; i++){
        newNode->p[i-1] = newNode->p[i];
    }
    
    newNode->totalKeys--;
    newMgr->totalEntries--;

    
    if (newNode->leaf){
        for (i = newNode->totalKeys; i < order-1; i++){
            newNode->p[i] = NULL;
        }
    }
    else{
        for (i = newNode->totalKeys+1; i < order; i++){
            newNode->p[i] = NULL;
        }
    }
    printf("NODE FOUND, ENTRY HAS BEEN REMOVED\n");

    
    
    if (newNode == newMgr->root){
        Node *newRoot = newMgr->root;
        
        if (newMgr->root->totalKeys > 0){
            newMgr->root = newMgr->root;
        }
        
        else if (!newMgr->root->leaf){
            newRoot = newMgr->root->p[0];
            newRoot = NULL;
            free(newMgr->root->key);
            free(newMgr->root->p);
            free(newMgr->root);
            newMgr->root = newRoot;
        }
        
        else{
            newMgr->root = NULL;
            free(newMgr->root->key);
            free(newMgr->root->p);
            free(newMgr->root);
            newMgr->root = newRoot;
        }
        printf("B+ TREE: BALANCED FOR ROOT CASE\n");
    }                         
    
    
    
    if (newNode->leaf){
        if ((order-1)%2 == 0){
            minKeys = (order-1)/2;
        }
        else{
            minKeys = (order-1)/2 +1;
        }
        printf("B+ TREE: BALANCED FOR LEAF CASE\n");
    }
    // if it's an inner node
    else{
        if (order%2 == 0){
            minKeys = (order)/2;
        }
        else{
            minKeys = (order)/2 +1;
        }
        minKeys--;
        printf("B+ TREE: BALANCED FOR NODE CASE\n");
    }
    
    
    if(newNode->totalKeys >= minKeys){
        return newMgr->root;
    }

    for (i = 0; i <= newNode->parent->totalKeys; i++){
        if (newNode->parent->p[i] == newNode){
            neighborIndex = i-1;
            break;
        }
    }

    if (neighborIndex == -1){
        kIndex = 0;
    }
    else{
        kIndex = neighborIndex;
    }
    k = newNode->parent->key[kIndex];


    if(neighborIndex == -1){
        neighborNode = newNode->parent->p[1];
    }
    else{
        neighborNode = newNode->parent->p[neighborIndex];
    }

    if (newNode->leaf){
        capacity = order;
    }
    else{
        capacity = order-1;
    }
    
    
    if (neighborNode->totalKeys + newNode->totalKeys < capacity){
        int insertIndex, end, x, y;
        Node *temp;
        if(neighborIndex == -1){
            temp = newNode;
            newNode = neighborNode;
            neighborNode = temp;
        }
        insertIndex = neighborNode->totalKeys;
        
        if (!newNode->leaf){
            neighborNode->key[insertIndex] = k;
            neighborNode->totalKeys++;
            end = newNode->totalKeys;
            for (x = insertIndex+1, y = 0; y < end; x++, y++){
                neighborNode->key[x] = newNode->key[y];
                neighborNode->p[x] = newNode->p[y];
                neighborNode->totalKeys++;
                newNode->totalKeys--;
            }
            neighborNode->p[x] = newNode->p[y];
            for(x=0; x<neighborNode->totalKeys+1; x++){
                temp = (Node*)neighborNode->p[x];
                temp->parent = neighborNode;
            }
            printf("MERGED WITH NODE\n");
        }
        // ------------------leaf case---------------------
        else{
            for (x = neighborIndex, y=0; y<newNode->totalKeys; x++, y++){
                neighborNode->key[x] = newNode->key[y];
                neighborNode->p[x] = neighborNode->key[y];
                neighborNode->totalKeys++;
            }
            neighborNode->p[order-1] = newNode->p[order-1];
            printf("MERGED WITH LEAF\n");
        }
        newMgr->root = delRecord(tree, newNode->parent, k, newNode);
        // free(newNode->key);
	    // free(newNode->p);
	    // free(newNode);
        printf("TREE HAS BEEN RE-BALANCED\n");
	    return newMgr->root;
    } // end if merging nodes

    
    else{
        int z;
        Node *temp;
        if (neighborIndex != -1){
            if(!newNode->leaf){
                newNode->p[newNode->totalKeys+1] = newNode->p[newNode->totalKeys];
            }
            // adjust the keys and pointers
            for (z = newNode->totalKeys; z>0; z--){
                newNode->key[z] = newNode->key[z-1];
                newNode->p[z] = newNode->p[z-1];
            }
            if (!newNode->leaf){
                newNode->p[0] = neighborNode->p[neighborNode->totalKeys];
                temp = (Node*)newNode->p[0];
                temp->parent = newNode;
                neighborNode->p[neighborNode->totalKeys] = NULL;
                newNode->key[0] = k;
                newNode->parent->key[kIndex] = neighborNode->key[neighborNode->totalKeys-1];
            }
            else{
                newNode->p[0] = neighborNode->p[neighborNode->totalKeys-1];
                neighborNode->p[neighborNode->totalKeys-1] = NULL;
                newNode->key[0] = neighborNode->key[neighborNode->totalKeys-1];
                newNode->parent->key[kIndex] = newNode->key[0];
            }
            printf("REDISTRIBUTED WITH NODE\n");
        } // end if neighborIndex != -1
        else{
            if (newNode->leaf) {
                newNode->key[newNode->totalKeys] = neighborNode->key[0];
                newNode->p[newNode->totalKeys] = neighborNode->p[0];
                newNode->parent->key[kIndex] = neighborNode->key[1];
            }
            else {
                newNode->key[newNode->totalKeys] = k;
                newNode->p[newNode->totalKeys+1] = neighborNode->p[0];
                temp = (Node*)newNode->p[newNode->totalKeys+1];
                temp->parent = newNode;
                newNode->parent->key[kIndex] = neighborNode->key[0];
            }
            for (z = 0; z < neighborNode->totalKeys-1; z++) {
                neighborNode->key[z] = neighborNode->key[z+1];
                neighborNode->p[z] = neighborNode->p[z+1];
            }
            if (!newNode->leaf)
                neighborNode->p[z] = neighborNode->p[z+1];
            printf("REDISTRIBUTED WITH LEAF\n");
        } // end else where neighborIndex == -1
        // update counters
        newNode->totalKeys++;
        neighborNode->totalKeys--;
        return newMgr->root;
    } // end else redistribute
}
        
extern RC deleteKey (BTreeHandle *tree, Value *key){
    
    IndexMgr *newMgr = (IndexMgr*) tree->mgmtData;
    if (newMgr->root == NULL) {
        return RC_IM_KEY_NOT_FOUND;
    }
    
    
    Node *tempNode;
    Node *tempLeaf;
    
    
    tempNode = getLeafNode(newMgr->root, key);
    int i;
    for (i = 0; i < tempNode->totalKeys; i++) {
        if (key->v.intV == tempNode->key[i]->v.intV) {
            break;
        }
    }
    tempNode = tempNode->p[i];
    tempLeaf = getLeafNode(newMgr->root, key); 
    if (tempLeaf != NULL && tempNode != NULL){
        newMgr->root = delRecord(tree, tempLeaf, key, tempNode);
    }
    free(tempNode);
    free(tempLeaf);
    printf("KEY DELETED\n");
    return RC_OK;
}


typedef struct ScanData {
    Node *scanNode;
    int keyLocation;
    int order;
} ScanData;

extern RC openTreeScan (BTreeHandle *tree, BT_ScanHandle **handle){
    // get metadata
    IndexMgr *newMgr = (IndexMgr*)tree->mgmtData;

    // allocate memory for scanner
    *handle = malloc(sizeof(BT_ScanHandle));

    Node *node = newMgr->root;
    if (node == NULL) {
        // there is nothing to scan
        return RC_FILE_NOT_FOUND;
    }
    // go to leftmost leaf
    while (node->leaf == FALSE) {
        node = node->p[0];
    }

    // initialize scan information
    ScanData *scanner = malloc(sizeof(ScanData));
    scanner->scanNode = node;
    scanner->keyLocation = 0;
    scanner->order = newMgr->order;
    (*handle)->mgmtData = scanner;

    return RC_OK;
}

extern RC nextEntry (BT_ScanHandle *handle, RID *result){
    // retrieve metadata
    ScanData * scanner = (ScanData *) handle->mgmtData;
    Node *node = scanner->scanNode;
    RID r;

    if (node == NULL) {
        return RC_IM_NO_MORE_ENTRIES;
    }

    // check if the entry exists on the current leaf
    if (scanner->keyLocation < node->totalKeys) {
        r = *(RID *)node->p[scanner->keyLocation];
        scanner->keyLocation++;
        *result = r;
        return RC_OK;
    }
    // move to the next node if all keys on the current leaf have been scanned
    if (node->p[scanner->order - 1] != NULL) {
        node = node->p[scanner->order - 1];
        scanner->keyLocation = 1;
        scanner->scanNode = node;
        r = *(RID *)node->p[0];
    }
    else {
        return RC_IM_NO_MORE_ENTRIES;
    }
    *result = r;
    return RC_OK;
}

extern RC closeTreeScan (BT_ScanHandle *handle){
    // reset index pointer
    handle->mgmtData = NULL;
    free(handle);
    return RC_OK;
}


// debug and test functions
extern char *printTree (BTreeHandle *tree){
    IndexMgr *newMgr = (IndexMgr*)tree->mgmtData;
    Node *node;
    if (newMgr->root == NULL) {
        printf("EMPTY TREE\n");
        return '\0';
    }
    return '\0';
}
